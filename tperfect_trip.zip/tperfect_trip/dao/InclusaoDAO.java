package com.tperfect_trip.dao;

public class InclusaoDAO {

}
